## Copyright (C) 2000, 2001, 2002, 2003 Red Hat, Inc.
## Copyright (C) 2000, 2001, 2002, 2003 Brent Fox <bfox@redhat.com>
##                                      Tammy Fox <tfox@redhat.com>

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

import string
import sys
import os

class ProfileSystem:
    def __init__(self, kickstartData):
        self.kickstartData = kickstartData
        
        self.getLang()
        self.getKeyboard()
        self.getMouse()
        self.getTimezone()
        self.getRootPassword()
        self.getPackages()

        self.kickstartData.setCdrom("cdrom")
        self.kickstartData.setInstall("install")
        self.kickstartData.setZeroMbr("yes")
        self.kickstartData.setClearPart(["--linux"])

    def getLang(self):
        self.kickstartData.setLang(["en_US.UTF-8"]) # default

        try:
            default_locale = open("/etc/default/locale")
            for line in default_locale:
                if line.startswith("LANG="):
                    default = line[5:].replace('"', '').strip()
                    self.kickstartData.setLang([default])
                    self.kickstartData.setDefaultLang(default)
                    break
            default_locale.close()
        except IOError:
            pass

        langs = []
        supported_dir = "/var/lib/locales/supported.d"
        try:
            supported_files = os.listdir(supported_dir)
            supported_files.sort()
            for supported_file in supported_files:
                supported = open(os.path.join(supported_dir, supported_file))
                for line in supported:
                    if line.startswith('#'):
                        continue
                    langs.append(line.strip().split(None, 1)[0])
                supported.close()
        except (OSError, IOError):
            pass
        self.kickstartData.setLangSupport(langs)

    def getKeyboard(self):
        self.kickstartData.setKeyboard(["us"]) # default

        layout = None
        variant = None
        try:
            console_setup = open("/etc/default/console-setup")
            for line in console_setup:
                if line.startswith("XKBLAYOUT="):
                    layout = line[10:].replace('"', '').strip()
                elif line.startswith("XKBVARIANT="):
                    variant = line[11:].replace('"', '').strip()
            console_setup.close()
        except IOError:
            pass
        if layout:
            if variant:
                self.kickstartData.setKeyboard(["%s_%s" % (layout, variant)])
            else:
                self.kickstartData.setKeyboard([layout])

    def getMouse(self):
        self.kickstartData.setMouse(["none"])

    def getTimezone(self):
        timezone_file = open('/etc/timezone')
        zone = timezone_file.readline().strip()
        timezone_file.close()

        self.kickstartData.setTimezone([zone])

    def getRootPassword(self):
        if os.access('/etc/shadow', os.R_OK) == 1:
            line = open('/etc/shadow', 'r').readline()
            tokens = string.split(line, ":")
            if tokens[1] == '!':
                self.kickstartData.setRootPw(None)
                print """\
The root password is disabled. You must set up an initial user (using the
'user' command) before using this output file."""
            else:
                passwd = "--iscrypted " + tokens[1]
                self.kickstartData.setRootPw([passwd])
        else:
            print "no access to /etc/shadow"

    def getPackages(self):
        fd = os.popen("dpkg-query --show --showformat '${package}\n'")
        packages = fd.readlines()
        fd.close
        packages.sort()

        for package in packages:
            packages[packages.index(package)] = string.strip(package)

        self.kickstartData.setIndividualPackageList(packages)
