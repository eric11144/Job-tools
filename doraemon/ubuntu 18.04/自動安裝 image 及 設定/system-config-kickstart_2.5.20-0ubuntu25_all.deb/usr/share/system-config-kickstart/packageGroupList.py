##
## I18N
## 
import gettext
domain = 'system-config-kickstart'
gettext.bindtextdomain(domain, '/usr/share/locale')
gettext.textdomain(domain)
_ = gettext.gettext
import os
import string
import sys
import tempfile
import apt_pkg

# Group names are hard-coded for now.

apt_group_names = {
    'ubuntu-desktop': "Ubuntu Desktop",
    'kubuntu-desktop': "Kubuntu Desktop",
}

class apt_group:
    def __init__(self, id, name):
        self.id = id
        self.name = name
        self.translated_name = {}

class apt_comps:
    def __init__(self):
        self.hierarchy = {
            'Desktops': ['ubuntu-desktop', 'kubuntu-desktop'],
            'Applications': [],
            'Servers': [],
            'Development': [],
            'System': []
        }

        self.groups = {}
        availfile = tempfile.TemporaryFile()
        pid = os.fork()
        if not pid:
            os.dup2(availfile.fileno(), sys.stdout.fileno())
            os.execlp("apt-cache", "apt-cache", "dumpavail")
        os.waitpid(pid, 0)
        availfile.seek(0)
        availparse = apt_pkg.TagFile(availfile)
        while availparse.step() == 1:
            if availparse.section.has_key("Task"):
                task = availparse.section["Task"]
                if not self.groups.has_key(task):
                    if apt_group_names.has_key(task):
                        taskname = apt_group_names[task]
                    else:
                        taskname = task
                    self.groups[task] = apt_group(task, taskname)

    def getGroupById(self, subgroup):
        if self.groups.has_key(subgroup):
            return self.groups[subgroup]
        else:
            return None

#try:
#    comps_file = rhpl.comps.Comps("/usr/share/comps/" + rhpl.getArch() + "/comps.xml")
#except:
#    print (_("Could not start because there is no /usr/share/comps/" + rhpl.getArch() + "/comps.xml file."))
#    print(_("Please make sure the comps package is installed."))
#    sys.exit(0)
comps_file = apt_comps()

desktopsList = []
applicationsList = []
serversList = []
developmentList = []
systemList = []

# Converts a single language into a "language search path". For example,
# fr_FR.utf8@euro would become "fr_FR.utf8@eueo fr_FR.utf8 fr_FR fr"
def expandLangs(str):
    langs = [str]
    # remove charset ...
    if '.' in str:
        langs.append(string.split(str, '.')[0])

    if '@' in str:
        langs.append(string.split(str, '@')[0])

    # also add 2 character language code ...
    if len(str) > 2:
        langs.append(str[:2])

    return langs

def do_translate (id):
    if os.environ.has_key("LANG"):
        langs = expandLangs(os.environ["LANG"])
    else:
        langs = []

    for lang in langs:
        if id.translated_name.has_key(lang):
            return id.translated_name[lang]

    return id.name

for subgroup in comps_file.hierarchy['Desktops']:
    id = comps_file.getGroupById(subgroup)
    if id != None:
        desktopsList.append ((do_translate(id), subgroup))

for subgroup in comps_file.hierarchy['Applications']:
    id = comps_file.getGroupById(subgroup)
    if id != None:
        applicationsList.append ((do_translate(id), subgroup))

for subgroup in comps_file.hierarchy['Servers']:
    id = comps_file.getGroupById(subgroup)
    if id != None:
        serversList.append ((do_translate(id), subgroup))

for subgroup in comps_file.hierarchy['Development']:
    id = comps_file.getGroupById(subgroup)
    if id != None:
        developmentList.append ((do_translate(id), subgroup))

for subgroup in comps_file.hierarchy['System']:
    id = comps_file.getGroupById(subgroup)
    if id != None:
        systemList.append ((do_translate(id), subgroup))
