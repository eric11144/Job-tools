import string
import subprocess
import gzip

# Get language code => full name mapping; TODO: internationalisation
langNames = {}
lines = gzip.open("/usr/share/localechooser/languagelist.data.gz", "r").readlines()

for line in lines:
    if line.startswith('#'):
        continue
    tokens = line.split(':')
    code = tokens[1]
    fullname = tokens[2]
    langNames[code] = fullname

# Get country code => full name mapping; TODO: internationalisation
countryNames = {}
isoquery = subprocess.Popen(['isoquery', '-c'], stdout=subprocess.PIPE)

for line in isoquery.stdout:
    line = line.rstrip('\n')
    tokens = line.split('\t')
    code = tokens[0]
    fullname = tokens[3]
    countryNames[code] = fullname

isoquery.wait()

#pull list of language from SUPPORTED file
langDict = {}

lines = open("/usr/share/i18n/SUPPORTED", "r").readlines()

for line in lines:
    code = line.rstrip('\n').split()[0]

    if '.' in code:
        #Chop encoding off so we can compare to self.installedLangs
        langBase = string.split(code, '.')
        langBase = langBase[0]
    elif '@' in code:
        langBase = string.split(code, '@')
        langBase = langBase[0]
    else:
        langBase = code

    if '_' in langBase and langBase not in langNames:
        (lang, country) = langBase.split('_')
        if lang not in langNames or country not in countryNames:
            continue
        name = '%s (%s)' % (langNames[lang], countryNames[country])
    else:
        if langBase not in langNames:
            continue
        name = langNames[langBase]

    name = string.strip(name)
    langDict[name] = langBase

# fetch language list from console-setup
layoutDict = {}
variantDict = {}

kbdnames = subprocess.Popen(
    ['/usr/share/console-setup/kbdnames-maker',
     '/usr/share/console-setup/KeyboardNames.pl'],
    stdout=subprocess.PIPE)
for line in kbdnames.stdout:
    line = line.rstrip('\n')
    tokens = line.split('*')
    if tokens[0] != 'C':
        continue
    if tokens[1] == 'layout':
        layoutDict[tokens[3]] = tokens[2]
    elif tokens[1] == 'variant':
        if tokens[2] not in variantDict:
            variantDict[tokens[2]] = {}
        variantDict[tokens[2]][tokens[4]] = tokens[3]
kbdnames.wait()

#define mice, add mice here
mouseDict = { "No Mouse" : "none",
                   "ALPS GlidePoint (PS/2)" : "alpsps/2",
                   "ASCII MieMouse (serial)" : "ascii",
                   "ASCII MieMouse (PS/2)" : "asciips/2",
                   "ATI Bus Mouse" : "atibm",
                   "Generic Mouse (serial)" : "generic",
                   "Generic 3 Button Mouse (serial)" : "generic3",
                   "Generic Mouse (PS/2)" : "genericps/2",
                   "Generic 3 Button Mouse (PS/2)" : "generic3ps/2",
                   "Generic Mouse (USB)" : "genericusb",
                   "Generic 3 Button Mouse (USB)" : "generic3usb",
                   "Genius NetMouse (serial)" : "geniusnm",
                   "Genius NetMouse (PS/2)" : "geniusnmps/2",
                   "Genius NetMouse Pro (PS/2)" : "geniusprops/2",
                   "Genius NetScroll (PS/2)" : "geniusscrollps/2",
                   "Kensington Thinking Mouse (serial)" : "thinking",
                   "Kensington Thinking Mouse (PS/2)" : "thinkingps/2",
                   "Logitech Mouse (serial, old C7 type)" : "logitech",
                   "Logitech CC Series (serial)" : "logitechcc",
                   "Logitech Bus Mouse" : "logibm",
                   "Logitech MouseMan/FirstMouse (serial)" : "logimman",
                   "Logitech MouseMan/FirstMouse (PS/2)" : "logimmanps/2",
                   "Logitech MouseMan+/FirstMouse+ (serial)" : "logimman+",
                   "Logitech MouseMan+/FirstMouse+ (PS/2)" : "logimman+ps/2",
                   "Logitech MouseMan Wheel (USB)" : "logimmusb",
                   "Microsoft compatible (serial)" : "microsoft",
                   "Microsoft Rev 2.1A or higher (serial)" : "msnew",
                   "Microsoft IntelliMouse (serial)" : "msintelli",
                   "Microsoft IntelliMouse (PS/2)" : "msintellips/2",
                   "Microsoft IntelliMouse (USB)" : "msintelliusb",
                   "Microsoft Bus Mouse" : "msbm",
                   "Mouse Systems (serial)" : "mousesystems",
                   "MM Series (serial)" : "mmseries",
                   "MM HitTablet (serial)" : "mmhittab",
                   "Sun Mouse" : "sun",
                   }
