## Kickstart Configurator - A graphical kickstart file generator
## Mouse emulation for Debian/Ubuntu-style systems
## Copyright (C) 2005 Canonical Ltd.

class Mouse:
    def __init__(self):
        self.models = [
            # psaux
            "PS/2", "ImPS/2", "GlidePointPS/2", "NetMousePS/2",
            "NetScrollPS/2", "ThinkingMousePS/2", "MouseManPlusPS/2",
            "ExplorerPS/2",
            # ttyS
            "Auto", "Microsoft", "MouseSystems", "GlidePoint", "ThinkingMouse",
            "ValuMouseScroll", "MouseMan", "Logitech", "IntelliMouse",
            "MMSeries", "MMHitTab",
            # atibm, atixl, sunmouse
            "BusMouse"
        ]

        self.mice = {}
        for mouse in self.models:
            # for that little bit of compatibility with rhpl.mouse
            self.mice[mouse] = (None, None, None, None, None, mouse)

    def available(self):
        return self.mice
